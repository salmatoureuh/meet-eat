import json
import mysql.connector

# Connexion à la base de données MySQL
db_connection = mysql.connector.connect(
    host="localhost",
    user="root",  
    password="AMU25",  
    database="meet_eat"
)

cursor = db_connection.cursor()

# Charger les données du fichier JSON
with open('campus.json', 'r', encoding='utf-8') as file:
    campus_data = json.load(file)

# Ajouter des tables à chaque campus
for campus in campus_data:
    campus_id = campus.get("id")  # Récupérer l'id du campus depuis JSON
    tables = campus.get("tables", [])

    for table in tables:
        numero_table = table["num"]
        capacite = table["capacite"]
        
        # Insérer les tables dans la base de données
        insert_query = """
            INSERT INTO campus_tables (campus_id, numero_table, est_reserve)
            VALUES (%s, %s, %s)
        """
        
        # False pour "est_reserve" puisque la table n'est pas réservée par défaut
        cursor.execute(insert_query, (campus_id, numero_table, False))

# Commit pour valider les changements
db_connection.commit()

# Fermer la connexion
cursor.close()
db_connection.close()

print("Les tables ont été ajoutées avec succès !")
