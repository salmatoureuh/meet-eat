import mysql.connector
from flask_sqlalchemy import SQLAlchemy

# Home (Database connection and initialization)
# Connexion à MySQL (pour la création de la base de données)
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="AMU25"  # Mets ton mot de passe ici si nécessaire
)

cursor = conn.cursor()

# ✅ Création de la base de données si elle n'existe pas
cursor.execute("CREATE DATABASE IF NOT EXISTS meet_eat;")
print("✅ Base de données créée ou déjà existante.")
cursor.execute("USE meet_eat;")

# Configuration SQLAlchemy
SQLALCHEMY_DATABASE_URI = 'mysql+mysqlconnector://root:AMU25@localhost/meet_eat'
db = SQLAlchemy()

def get_db_connection():
    """Retourne une connexion à la base de données MySQL."""
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="AMU25",
        database="meet_eat"
    )

# Signup, Login, Profile
# ✅ Définition des tables liées aux utilisateurs
sql_statements = [
    """
    CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nom VARCHAR(100) NOT NULL,
        prenom VARCHAR(100) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        image TEXT,
        num_etudiant VARCHAR(15) UNIQUE NOT NULL,
        campus_id INT NOT NULL,
        ville VARCHAR(100) NOT NULL,
        adresse VARCHAR(200) NOT NULL,
        pseudo VARCHAR(30) UNIQUE NOT NULL,
        date_inscription TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (campus_id) REFERENCES campus(id) ON DELETE CASCADE
    );
    """,
]

# Booking
# ✅ Définition des tables liées aux réservations
sql_statements += [
    """
    CREATE TABLE IF NOT EXISTS campus_tables (
        id INT AUTO_INCREMENT PRIMARY KEY,
        campus_id INT NOT NULL,
        numero_table INT NOT NULL,
        est_reserve BOOLEAN DEFAULT FALSE,
        UNIQUE (campus_id, numero_table),
        FOREIGN KEY (campus_id) REFERENCES campus(id) ON DELETE CASCADE
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS reservation (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    table_id INT NOT NULL,
    date_reservation DATETIME NOT NULL,  -- Vérifiez que c'est bien 'date_reservation' et non 'reservation_datetime'
    heure_debut TIME NOT NULL,
    heure_fin TIME NOT NULL,
    campus_nom VARCHAR(255) NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (table_id) REFERENCES campus_tables(id) ON DELETE CASCADE
    );
    """,
]

# Private Meals
# ✅ Définition des tables liées aux repas privés
sql_statements += [
    """
    CREATE TABLE IF NOT EXISTS private_meals (
        id INT AUTO_INCREMENT PRIMARY KEY,
        organisateur_id INT NOT NULL,
        date_repas DATETIME NOT NULL,
        heure TIME NOT NULL,
        campus_id INT NOT NULL,
        FOREIGN KEY (organisateur_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (campus_id) REFERENCES campus(id) ON DELETE CASCADE
    );
    """,
]

# Reservations (Grouped Here)
# Already included in the Booking section above.

# Notifications
# ✅ Définition des tables liées aux notifications
sql_statements += [
    """
    CREATE TABLE IF NOT EXISTS notifications (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        message TEXT NOT NULL,
        est_lu BOOLEAN DEFAULT FALSE,
        date_notification TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        type ENUM('réservation', 'invitation', 'autre') DEFAULT 'autre',
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        INDEX (est_lu)
    );
    """,
]

# Search
# No specific tables related to search in this context.

# Invitations
# ✅ Définition des tables liées aux invitations
sql_statements += [
    """
    CREATE TABLE IF NOT EXISTS invitations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    friend_id INT NOT NULL,
    statut ENUM('en attente', 'accepté', 'refusé') DEFAULT 'en attente',
    UNIQUE (user_id, friend_id),  -- Clé unique sur les deux colonnes
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (friend_id) REFERENCES users(id) ON DELETE CASCADE
    );
    """,
]

# Friends
# ✅ Définition des tables liées aux amis
sql_statements += [
    """
    CREATE TABLE IF NOT EXISTS friends (
     id INT AUTO_INCREMENT PRIMARY KEY,
     user_id INT NOT NULL,
     friend_id INT NOT NULL,
     statut ENUM('en attente', 'accepté', 'refusé') DEFAULT 'en attente',
     UNIQUE (LEAST(user_id, friend_id), GREATEST(user_id, friend_id)),  -- Normaliser l'ordre
     FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
     FOREIGN KEY (friend_id) REFERENCES users(id) ON DELETE CASCADE
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS friend_requests (
        id INT AUTO_INCREMENT PRIMARY KEY,
        sender_id INT NOT NULL,
        receiver_id INT NOT NULL,
        statut ENUM('en attente', 'accepté', 'refusé') DEFAULT 'en attente',
        UNIQUE (sender_id, receiver_id),
        FOREIGN KEY (sender_id) REFERENCES users(id),
        FOREIGN KEY (receiver_id) REFERENCES users(id)
    );
    """,
]

# Chat
# ✅ Définition des tables liées à la messagerie
sql_statements += [
    """
   CREATE TABLE IF NOT EXISTS messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        sender_id INT NOT NULL,
        receiver_id INT NOT NULL,
        message TEXT NOT NULL,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE
    );

    -- Add the `discussion_id` column to the `messages` table after it's created
    ALTER TABLE messages ADD COLUMN discussion_id INT;

    -- Add the foreign key constraint for `discussion_id`
    ALTER TABLE messages ADD FOREIGN KEY (discussion_id) REFERENCES discussions(id) ON DELETE CASCADE;
    """,
]

sql_statements += [
     """
    CREATE TABLE discussions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        sender_id INT NOT NULL,
        recipient_id INT NOT NULL,
        last_message_id INT DEFAULT NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (recipient_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (last_message_id) REFERENCES messages(id) ON DELETE SET NULL
    );
   """,
]

# Campus
# ✅ Définition des tables liées au campus
sql_statements += [
    """
    CREATE TABLE IF NOT EXISTS campus (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nom VARCHAR(255) NOT NULL,
    adresse VARCHAR(255),
    ville VARCHAR(100),
    code_postal VARCHAR(20),
    horaires VARCHAR(255),
    paiement VARCHAR(100),
    lat DOUBLE,
    lng DOUBLE
    );
    """,
]

# ✅ Exécution des requêtes SQL
for sql in sql_statements:
    try:
        cursor.execute(sql)
        table_name = sql.split('(')[0].split()[-1]
        print(f"✅ Table créée ou déjà existante : {table_name}")
    except mysql.connector.Error as err:
        print(f"❌ Erreur lors de la création de {table_name} : {err}")

# ✅ Valider et fermer la connexion
conn.commit()
cursor.close()
conn.close()
print("🎉 Toutes les tables ont été créées avec succès !")