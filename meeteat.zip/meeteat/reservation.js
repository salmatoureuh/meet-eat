document.getElementById("reservation-form").addEventListener("submit", function(event) {
    event.preventDefault();
    
    const date = document.getElementById("date").value;
    const heureDebut = document.getElementById("heure-debut").value;
    const heureFin = document.getElementById("heure-fin").value;
    const campus = document.getElementById("campus").value;
    const tableId = parseInt(document.getElementById("table").value);

    // Vérification si la date est un jour de la semaine (lundi à vendredi)
    const selectedDate = new Date(date);
    const dayOfWeek = selectedDate.getDay(); // 0 = dimanche, 1 = lundi, ...

    if (dayOfWeek === 0 || dayOfWeek === 6) {
        document.getElementById("alert").textContent = "❌ Vous ne pouvez réserver que du lundi au vendredi.";
        document.getElementById("alert").style.display = "block";
        return;
    }

    // Vérification des horaires : heure de début et de fin
    const debut = parseInt(heureDebut.split(":")[0]); // Heure de début
    const fin = parseInt(heureFin.split(":")[0]);   // Heure de fin

    // Vérification des plages horaires autorisées
    if (!((debut >= 12 && debut < 14) || (debut >= 18 && debut < 20))) {
        document.getElementById("alert").textContent = "❌ Vous ne pouvez réserver que pendant les horaires d'ouverture du restaurant : 12h-14h ou 18h-20h.";
        document.getElementById("alert").style.display = "block";
        return;
    }
    
    // Vérification que l'heure de fin est après l'heure de début
    if (fin <= debut) {
        document.getElementById("alert").textContent = "❌ L'heure de fin doit être après l'heure de début.";
        document.getElementById("alert").style.display = "block";
        return;
    }

    // Assuming the reservation logic here
    let table = tables[campus].find(t => t.id === tableId);
    if (table.reserved < table.capacity) {
        table.reserved++;
        localStorage.setItem("reservation", JSON.stringify({ date, heureDebut, heureFin, campus, tableId }));
        alert(`✅ Réservation confirmée pour la Table ${tableId} à ${campus} !`);
        updateTables(); // Mettre à jour les tables disponibles
        window.location.href = 'confirmations.html';
    } else {
        alert("❌ Cette table est déjà complète !");
    }
});