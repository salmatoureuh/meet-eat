import os
import json
import re
import datetime
import uuid
from datetime import time
from flask import Flask, render_template, request, redirect, url_for, session, Blueprint, jsonify, flash
from flask_login import login_required, current_user, login_user, LoginManager, logout_user
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename
import mysql.connector
from models import (
    db, init_app, Reservation, User, Message,Invitation, Campus, CampusTable, get_user_by_email, get_user_by_num_etudiant,
    get_user_by_field, get_user_info, get_db_connection, create_user,
    update_user_info, delete_user_by_id, get_campus_info, add_friend, send_invitation,
    create_notification, send_message, create_private_meal, get_reservations_from_db,
    create_reservation, delete_reservation_from_db, add_reservation_notification,
    add_friend_request_notification, send_notification,
    mark_notification_as_read, get_unread_notifications, search_friends, is_valid_password, get_campus_id_by_name,allowed_file, get_campuses_from_db,
)
import uuid
import re
from config import ALLOWED_EXTENSIONS
from sqlalchemy import or_
from flask import current_app
from functools import wraps

# Create the Flask app instance
app = Flask(__name__)

# Configure the app
app.config["ALLOWED_EXTENSIONS"] = ALLOWED_EXTENSIONS
app.config['SECRET_KEY'] = os.urandom(24)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root:AMU25@localhost/meet_eat'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = os.path.join('static', 'uploads')
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Initialize login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'routes.login'

# === Load User ===
@login_manager.user_loader
def load_user(user_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
    user_data = cursor.fetchone()
    conn.close()
    
    if user_data:
        # Remove 'campus' from user_data to prevent it from causing issues
        user_data.pop('campus', None)  # This will remove 'campus' if it exists
        
        # Create the user object
        return User(**user_data)
    return None

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('routes.login'))  # ou selon le nom de ta route
        return f(*args, **kwargs)
    return decorated_function

# Initialize the application with the database
init_app(app)


# Define the Blueprint for routes
routes = Blueprint('routes', __name__)


UPLOAD_FOLDER = 'static/uploads'
@app.route('/upload_profile', methods=['POST'])
def upload_profile():
    if 'image' not in request.files:
        flash('Aucune image sélectionnée', 'danger')
        return redirect(request.url)

    file = request.files['image']

    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file_path = os.path.join(UPLOAD_FOLDER, filename)
        file.save(file_path)

        # Enregistre le nom du fichier dans la base de données
        # Assure-toi que l'utilisateur est connecté
        user_id = session['user_id']
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET image = %s WHERE id = %s", (filename, user_id))
        conn.commit()
        conn.close()

        flash('Photo de profil mise à jour !', 'success')
        return redirect(url_for('profile'))

    flash('Format de fichier non autorisé', 'danger')
    return redirect(request.url)

# === Home ===
@routes.route('/')
def home():
    """
    Logic: Display the home page of the application.
    - This is the default landing page.
    - It renders the `home.html` template.
    """
    return render_template('home.html')

@routes.route('/signup', methods=['GET', 'POST'])
def signup():
    """
    Logic: Handle user registration.
    - GET: Render the signup form with campus dropdown.
    - POST: Validate and create a new user.
    """
    # Load campuses for both GET and POST requests
    campuses = get_campuses_from_db()

    if request.method == 'POST':
        # Fetch form data
        prenom = request.form.get("prenom")
        nom = request.form.get("nom")
        pseudo = request.form.get("pseudo")
        email = request.form.get("email")
        num_etudiant = request.form.get("num_etudiant")
        campus = request.form.get("campus")
        ville = request.form.get("ville")
        adresse = request.form.get("adresse")
        password = request.form.get("password")
        confirm_password = request.form.get("confirm-password")
        image = request.files.get("image")

        # Log the received data
        print(f"Data received: {prenom=}, {nom=}, {pseudo=}, {email=}, {num_etudiant=}, {campus=}, {ville=}, {adresse=}, {password=}, {confirm_password=}")

        # Validate campus
        campus_id = int(campus) if campus.isdigit() else None
        if not campus_id:
            flash("Le campus sélectionné est invalide.", 'danger')
            return render_template("signup.html", campuses=campuses)

        # Validate required fields
        if not all([prenom, nom, pseudo, email, num_etudiant, campus, ville, adresse, password, confirm_password]):
            flash("Tous les champs obligatoires doivent être remplis.", 'danger')
            return render_template('signup.html', campuses=campuses)

        # Validate email format
        email_regex = r'^[a-zA-Z]+\.{1}[a-zA-Z]+@etu-univ\.fr$'
        if not re.match(email_regex, email):
            flash("L'adresse email doit être au format prenom.nom@etu-univ.fr", 'danger')
            return render_template('signup.html', campuses=campuses)

        # Validate student number
        if not num_etudiant.isdigit():
            flash("Le numéro étudiant doit contenir uniquement des chiffres.", 'danger')
            return render_template('signup.html', campuses=campuses)

        # Check for duplicate email or student number
        if get_user_by_email(email):
            flash("Cet email est déjà utilisé.", 'danger')
            return render_template('signup.html', campuses=campuses)

        if get_user_by_num_etudiant(num_etudiant):
            flash("Ce numéro étudiant est déjà utilisé.", 'danger')
            return render_template('signup.html', campuses=campuses)

        # Validate password
        if password != confirm_password:
            flash("Les mots de passe ne correspondent pas.", 'danger')
            return render_template('signup.html', campuses=campuses)

        if len(password) < 6:
            flash("Le mot de passe doit contenir au moins 6 caractères.", 'danger')
            return render_template('signup.html', campuses=campuses)

        if not is_valid_password(password):
            flash("Le mot de passe doit contenir une majuscule, une minuscule, un chiffre et un caractère spécial.", 'danger')
            return render_template('signup.html', campuses=campuses)

        # Validate image (if provided)
        if image and not allowed_file(image.filename):
            flash("Le format de l'image n'est pas autorisé.", 'danger')
            return render_template('signup.html', campuses=campuses)

        # Hash the password
        password_hash = generate_password_hash(password, method='pbkdf2:sha256')

        # Handle image upload (if provided)
        image_filename = None
        if image:
            filename = secure_filename(image.filename)
            image_filename = f"{uuid.uuid4().hex}_{filename}"
            # Save image to a desired location (e.g., `uploads/`)
            image.save(f"static/uploads/{image_filename}")

        # Create the user
        created = create_user(
            prenom=prenom,
            nom=nom,
            pseudo=pseudo,
            email=email,
            password_hash=password_hash,
            num_etudiant=num_etudiant,
            campus_id=campus_id,
            ville=ville,
            adresse=adresse,
            image=image_filename
        )

        # Handle user creation result
        if created:
            flash("Inscription réussie...", "success")
            return redirect(url_for("routes.login"))
        else:
            flash("Une erreur est survenue...", "danger")
            return render_template("signup.html", campuses=campuses)

    # Handle GET request
    return render_template('signup.html', campuses=campuses)

@routes.route('/login', methods=['GET', 'POST'])
def login():
    """
    Logic: Handle user login.
    - GET: Render the login form.
    - POST: Authenticate user based on email or student ID and password.
    - Redirects to the booking page upon successful login.
    """
    if request.method == 'POST':
        identifiant = request.form['num_etudiant']  
        password = request.form['password']

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        if '@' in identifiant:
            cursor.execute("SELECT * FROM users WHERE email = %s", (identifiant,))
        else:
            cursor.execute("SELECT * FROM users WHERE num_etudiant = %s", (identifiant,))

        user_data = cursor.fetchone()
        conn.close()

        if user_data and check_password_hash(user_data['password_hash'], password):
            # Remove 'campus' from user_data to prevent it from causing issues
            user_data.pop('campus', None)  # This will remove 'campus' if it exists
            
            # Create the user object
            user = User(**user_data)
    
            session['user_id'] = user.id  # Corrected indentation
            # Log in the user
            login_user(user)
            flash('Connexion réussie !', 'success')
            return redirect(url_for('routes.booking'))
        else:
            flash('Identifiants ou mot de passe incorrects', 'danger')

    return render_template('login.html')

@routes.route('/logout')
@login_required
def logout():
    """
    Logic: Log the user out and redirect to the home page.
    """
    logout_user()
    flash("Vous êtes déconnecté.", "success")
    return redirect(url_for('routes.home'))

# === Profile ===
@app.route('/profile')
@login_required
def profile():
    user = User.query.get(current_user.id)
    campuses = get_campuses_from_db()

    # Informations de l'utilisateur
    user_info = {
        "prenom": current_user.prenom,
        "nom": current_user.nom,
        "email": current_user.email,
        "image": current_user.image if current_user.image else "default.jpg",
        "ville": current_user.ville,
        "adresse": current_user.adresse,
        "num_etudiant": current_user.num_etudiant,
        "campus": current_user.campus_id,
        "username": current_user.pseudo,
        "date_inscription": current_user.date_inscription
    }
    return render_template("profile.html", user_info=user_info, campus_list=campuses)


@app.route('/update_profile', methods=['POST'])
@login_required
def update_profile():
    # Récupérer les informations du formulaire
    pseudo = request.form.get('pseudo')  
    prenom = request.form.get('prenom')
    nom = request.form.get('nom')
    email = request.form.get('email')
    campus_id = request.form.get('campus_id')
    image = request.files.get('image')

    # Validation des champs nécessaires (si nécessaire)

    # Mettre à jour les informations de l'utilisateur dans la base de données
    user = User.query.get(current_user.id)
    if prenom:
        user.prenom = prenom
    if nom:
        user.nom = nom
    if email:
        user.email = email
    if campus_id:
        user.campus_id = campus_id
    if pseudo:
        user.pseudo = pseudo
    
    # Gérer l'image (si une nouvelle image a été téléchargée)
    if image:
        # Enregistrez l'image et mettez à jour le chemin dans l'utilisateur
        filename = secure_filename(image.filename)
        image.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        user.image = filename

    # Sauvegarder les modifications dans la base de données
    db.session.commit()

    # Flash du message de succès
    flash('Votre profil a été mis à jour avec succès !', 'success')

    # Rediriger vers la page de profil
    return redirect(url_for('profile'))


@app.route('/delete_account', methods=['POST'])
@login_required
def delete_account():
    """
    Logic: Delete the user's account.
    - Deletes user data from the database.
    - Logs the user out after deletion.
    """
    success = delete_user_by_id(current_user.id)
    if success:
        logout_user()
        flash('Votre compte a bien été supprimé.', 'success')
        return redirect(url_for('routes.login'))
    else:
        flash("Erreur lors de la suppression du compte.", 'danger')
        return redirect(url_for('profile'))

# === Booking ===
@routes.route('/booking', methods=['GET', 'POST'])
@login_required
def booking():
    """
    Logic: Handle both displaying the booking page and creating reservations.
    - GET: Display available tables and reservation options.
    - POST: Validate and create a new reservation entry in the database.
    """
    if request.method == 'POST':
        # Récupérer les données du formulaire
        date = request.form.get('date')  # Assurez-vous que le champ HTML s'appelle bien "date"
        heure_debut = request.form.get('heure-debut')  # Correspondre au champ HTML
        heure_fin = request.form.get('heure-fin')  # Correspondre au champ HTML
        campus = request.form.get('campus')
        table_id = request.form.get('tableId')
        
        # Ajoutez ce print pour déboguer et vérifier les valeurs reçues
        print(f"DEBUG - Données reçues: date={date}, heure_debut={heure_debut}, heure_fin={heure_fin}, campus={campus}, table_id={table_id}")

        # Validation des données
        if not date or not heure_debut or not heure_fin or not campus or not table_id:
            flash("Tous les champs doivent être remplis.", 'danger')
            return redirect(url_for('routes.booking'))
        
        # Convertir la date en objet datetime
        try:
            date_reservation = datetime.strptime(date, "%d-%m-%Y")
        except ValueError:
            flash("Format de date invalide.", 'danger')
            return redirect(url_for('routes.booking'))
        
        # Créer une nouvelle réservation
        new_reservation = Reservation(
            user_id=current_user.id,
            date_reservation=date_reservation,
            heure_debut=heure_debut,
            heure_fin=heure_fin,
            campus_nom=campus,
            table_id=int(table_id)
        )
        
        try:
            db.session.add(new_reservation)
            db.session.commit()
            flash('Réservation créée avec succès!', 'success')
        except Exception as e:
            db.session.rollback()
            flash(f'Erreur lors de la création de la réservation: {e}', 'danger')

        return redirect(url_for('routes.booking'))
    
    # GET : Afficher la page de réservation
    user_info = get_user_info(current_user.id)
    available_tables = db.session.query(CampusTable).all()

    return render_template('booking.html', user_info=user_info, available_tables=available_tables)

# === Private Meal ===
@routes.route('/privatemeal')
@login_required
def privatemeal():
    """
    Logic: Display the private meal page.
    - Allows users to create or view private meal events.
    """
    user_info = get_user_info(current_user.id)
    return render_template('privatemeal.html', user_info=user_info)

@routes.route('/create_private_meal', methods=['POST'])
@login_required
def create_private_meal_route():
    """
    Logic: Handle the creation of private meals.
    - Validates input fields like date, time, and campus selection.
    """
    date_repas = request.form.get("date_repas")
    heure = request.form.get("heure")
    campus_id = request.form.get("campus_id")

    if not all([date_repas, heure, campus_id]):
        flash("Tous les champs doivent être remplis.", 'danger')
        return redirect(url_for('routes.privatemeal'))

    organisateur_id = current_user.id
    new_meal_id = create_private_meal(organisateur_id, date_repas, heure, campus_id)

    if new_meal_id:
        flash(f"Repas privé créé avec succès ! ID du repas : {new_meal_id}", 'success')
        return redirect(url_for('profile'))
    else:
        flash("Erreur lors de la création du repas privé.", 'danger')
        return redirect(url_for('routes.privatemeal'))
    
# === Reservations ===
@routes.route('/reservations')
@login_required
def reservations():
    """
    Logic: Display the user's reservations.
    - Fetch reservation details for the logged-in user.
    - Renders the `reservations.html` template with user information.
    """
    user_info = get_user_info(current_user.id)
    return render_template('reservations.html', user_info=user_info)

@app.route('/show_reservations')
@login_required
def show_reservations():
    """
    Logic: Fetch and display all reservations for the user.
    - Displays reservations in a tabular format.
    """
    reservations = get_reservations_from_db(current_user.id)

    if not reservations:
        flash("Aucune réservation trouvée.", 'info')
    
    print(f"Reservations: {reservations}")  # Ajoute cette ligne pour vérifier les données récupérées

    return render_template('reservations.html', reservations=reservations)





@app.route('/delete_reservation/<int:reservation_id>', methods=['DELETE'])
@login_required
def delete_reservation(reservation_id):
    """
    Logic: Delete a specific reservation.
    - Removes the reservation entry from the database.
    """
    result = delete_reservation_from_db(reservation_id)
    if result:
        return jsonify({"message": "Réservation annulée avec succès."})
    else:
        return jsonify({"message": "Erreur lors de l'annulation."}), 400

@app.route('/get_reservations', methods=['GET'])
@login_required
def get_reservations():
    """
    Logic: Fetch reservation data in JSON format.
    - Useful for dynamically updating the frontend with reservations.
    """
    user_id = current_user.id
    reservations = get_reservations_from_db(user_id)
    return jsonify(reservations)

# === Notifications ===
@routes.route('/notifications')
@login_required
def notifications():
    """
    Logic: Display the user's notifications.
    - Fetches unread notifications for the logged-in user.
    - Renders the `notifications.html` template with user information and notifications.
    """
    user_info = get_user_info(current_user.id)
    notifications = get_unread_notifications(current_user.id)

    return render_template('notifications.html', user_info=user_info, notifications=notifications, connected=True)

@app.route('/get_notifications')
@login_required
def get_notifications():
    """
    Logic: Fetch notifications dynamically in JSON format.
    - Useful for real-time notification updates in the frontend.
    """
    notifications = get_unread_notifications(current_user.id)
    return jsonify(notifications)

# === Search ===
@routes.route('/search', endpoint='search')
@login_required
def search():
    """
    Logic: Render the search page.
    - Allows users to search for other users or content.
    """
    user_info = get_user_info(current_user.id)
    return render_template('search.html', user_info=user_info)

from flask import session, redirect, url_for


@routes.route('/search_user', methods=['GET'])
def search_user():
    query = request.args.get('query')

    user_id = session.get('user_id')
    conn = get_db_connection()

    if not conn:
        flash('Impossible de se connecter à la base de données.', 'danger')
        return render_template('search.html')

    cursor = conn.cursor(dictionary=True)

    # 🔎 Vérifie que query n'est pas None
    if query:
        search_term = f"%{query}%"
        cursor.execute("""
            SELECT * FROM users 
            WHERE nom LIKE %s OR prenom LIKE %s OR email LIKE %s OR num_etudiant LIKE %s
        """, (search_term, search_term, search_term, search_term))

        users = cursor.fetchall()
    else:
        users = []

    # 👤 Récupère les infos de l'utilisateur connecté (pour afficher sa photo par ex)
    user_info = None
    if user_id:
        cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
        user_info = cursor.fetchone()

    conn.close()

    # ✅ Envoie les données à la page avec les utilisateurs trouvés
    if users:
        return render_template('search.html', users=users, user_info=user_info)
    else:
        flash("Aucun utilisateur trouvé.", "warning")
        return render_template('search.html', users=[], user_info=user_info)



# === Invitations ===
@app.route("/get_invitations")
def get_invitations():
    # Récupérer les invitations d'ami de la base de données
    invitations = Invitation.query.filter_by(receveur_id=current_user.id).all()
    invitations_data = []
    for invite in invitations:
        # Inclure l'image de l'envoyeur dans la réponse
        envoyeur_image = invite.envoyeur.image if invite.envoyeur.image else 'default.jpg'
        invitations_data.append({
            'id': invite.id,
            'envoyeur_nom': invite.envoyeur.nom,
            'envoyeur_image': envoyeur_image,  # Renvoi de l'image
            'statut': invite.statut
        })
    
    return jsonify({'invitations': invitations_data})



@app.route("/invitations")
@login_required
def invitations():
    # Fetch all invitations where the current user is the receiver
    invitations = Invitation.query.filter_by(receveur_id=current_user.id).all()
    invitations_data = []

    for invite in invitations:
        envoyeur_image = invite.envoyeur.image if invite.envoyeur.image else 'default.jpg'
        invitations_data.append({
            'id': invite.id,
            'envoyeur_nom': invite.envoyeur.nom,
            'envoyeur_image': envoyeur_image,
            'statut': invite.statut
        })

    # Render the invitations page and pass the data
    return render_template('invitations.html', invitations=invitations_data)


@app.route("/invitation/<int:id>/<action>", methods=["POST"])
@login_required
def gerer_invitation(id, action):
    # Fetch the invitation by its ID
    invitation = Invitation.query.get(id)

    if invitation and invitation.receveur_id == current_user.id:
        if action == 'accepter':
            # Add the sender and receiver to the friends table
            new_friend = Friend(
                user_id=invitation.receveur_id,
                friend_id=invitation.envoyeur_id,
                statut='accepté'
            )
            db.session.add(new_friend)
            
            # Remove the invitation
            db.session.delete(invitation)
            
            # Commit the transaction
            db.session.commit()
            
            # Return success message
            return jsonify({"message": "Félicitations, vous êtes amis!"}), 200

        elif action == 'refuser':
            # Simply remove the invitation
            db.session.delete(invitation)
            db.session.commit()

            # Return refusal message
            return jsonify({"message": "Invitation refusée."}), 200

    # If invitation not found or unauthorized access
    return jsonify({'error': 'Invitation non trouvée ou accès refusé.'}), 404


@app.route("/send_invite", methods=["POST"])
def send_invite():
    data = request.get_json()
    email_destinataire = data.get("email")
    
    # Trouver l'utilisateur destinataire à partir de son email
    destinataire = User.query.filter_by(email=email_destinataire).first()
    
    if destinataire:
        # Créer une nouvelle invitation d'ami
        invitation = Invitation(
            envoyeur_id=current_user.id,
            receveur_id=destinataire.id,
            statut='en attente'
        )
        db.session.add(invitation)
        db.session.commit()
        
        return jsonify({"message": "Invitation d'amitié envoyée."}), 200
    else:
        return jsonify({"error": "Utilisateur non trouvé."}), 404

# === Friends ===
@app.route("/get_friends", methods=["GET"])
@login_required
def get_friends():
    """
    Logic: Fetch the user's friends and render the HTML template.
    """
    user_id = current_user.id

    # Fetch friends of the current user
    query = """
        SELECT u.id, u.nom, u.prenom 
        FROM users u
        JOIN friends f ON (f.user_id = u.id OR f.friend_id = u.id)
        WHERE (f.user_id = %s OR f.friend_id = %s) AND f.statut = 'accepté'
    """
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute(query, (user_id, user_id))
    friends = cursor.fetchall()
    cursor.close()
    conn.close()

    # Fetch user information (replace with actual logic to get the user's image)
    user_info = {"image": "default.jpg"}  # Replace "default.jpg" with actual user image logic

    # Render the template with friends and user_info
    return render_template("friends.html", friends=friends, user_info=user_info)

@app.route("/get_friends_paginated", methods=["GET"])
@login_required
def get_friends_paginated():
    user_id = current_user.id
    page = int(request.args.get("page", 1))
    limit = 20
    offset = (page - 1) * limit
    query = """
        SELECT u.id, u.nom, u.prenom 
        FROM users u
        JOIN friends f ON (f.user_id = u.id OR f.friend_id = u.id)
        WHERE (f.user_id = %s OR f.friend_id = %s) AND f.statut = 'accepté'
        LIMIT %s OFFSET %s
    """
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute(query, (user_id, user_id, limit, offset))
    friends = cursor.fetchall()
    cursor.close()
    conn.close()
    return jsonify(friends)

@app.route("/search_friends", methods=["GET"])
@login_required
def search_friends():
    search_query = request.args.get("query", "")
    user_id = current_user.id
    query = """
        SELECT u.id, u.nom, u.prenom 
        FROM users u
        JOIN friends f ON (f.user_id = u.id OR f.friend_id = u.id)
        WHERE (f.user_id = %s OR f.friend_id = %s) 
        AND f.statut = 'accepté' AND (u.nom LIKE %s OR u.prenom LIKE %s)
    """
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute(query, (user_id, user_id, f"%{search_query}%", f"%{search_query}%"))
    friends = cursor.fetchall()
    cursor.close()
    conn.close()
    return jsonify(friends)

@app.route("/delete_friend/<int:friend_id>", methods=["DELETE"])
@login_required
def delete_friend(friend_id):
    """
    Logic: Remove a friend from the user's friend list.
    - Deletes the friendship from the database.
    """
    user_id = current_user.id
    query = """
        DELETE FROM friends 
        WHERE (user_id = %s AND friend_id = %s) OR (user_id = %s AND friend_id = %s)
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(query, (user_id, friend_id, friend_id, user_id))
    conn.commit()
    cursor.close()
    conn.close()
    return jsonify({"success": True})




@routes.route('/friends')
@login_required
def friends():
    """
    Logic: Display the friends page.
    - Shows the user's friends and pending friend requests.
    """
    user_info = get_user_info(current_user.id)
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Fetch accepted friends
    cursor.execute("""
        SELECT u.id, u.nom, u.prenom
        FROM users u
        JOIN friends f ON u.id = f.friend_id
        WHERE f.user_id = %s AND f.statut = 'accepté'
    """, (current_user.id,))
    friends = cursor.fetchall()

    # Fetch pending requests
    cursor.execute("""
        SELECT u.id, u.nom, u.prenom
        FROM users u
        JOIN friends f ON u.id = f.user_id
        WHERE f.friend_id = %s AND f.statut = 'en attente'
    """, (current_user.id,))
    requests = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template('friends.html', user_info=user_info, friends=friends, requests=requests)

from flask import request, redirect, url_for, flash
from flask_login import current_user
import mysql.connector

@app.route('/send_message/<int:receiver_id>', methods=['POST'])
@login_required
def send_message_to_friend(receiver_id):
    """
    Logic: Send a message to another user.
    - Inserts the message into the database.
    """
    message = request.form['message']  # Get the message from the form
    sender_id = current_user.id
    
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Check if the receiver exists in the users table
        cursor.execute("SELECT id FROM users WHERE id = %s", (receiver_id,))
        receiver = cursor.fetchone()

        if not receiver:
            flash("Receiver not found!", "error")  # Flash message for the user
            return redirect(url_for('routes.chat', user_id=receiver_id))

        # Insert the message into the database
        cursor.execute("""
            INSERT INTO messages (sender_id, receiver_id, contenu)
            VALUES (%s, %s, %s)
        """, (sender_id, receiver_id, message))
        conn.commit()
        flash("✅ Message sent successfully.", "success")  # Flash success message

        # Redirect to the chat page with the receiver's id
        return redirect(url_for('routes.chat', user_id=receiver_id))

    except mysql.connector.Error as err:
        conn.rollback()  # Rollback any changes if an error occurs
        flash(f"❌ Error sending message: {err}", "error")  # Flash error message
        return redirect(url_for('routes.chat', user_id=receiver_id))

    finally:
        cursor.close()  # Always close the cursor
        conn.close()  # Always close the connection


# === Chat ===
@app.route('/chat', methods=['GET', 'POST'])
@login_required
def chat():
    # Fetch user info for displaying in the navbar
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM users WHERE id = %s", (current_user.id,))
    user_info = cursor.fetchone()
    if not user_info:
        flash("User information not found.", "error")
        return redirect(url_for('profile'))

    # Get the active discussion ID from the query parameters
    active_discussion_id = request.args.get('discussion_id')
    active_discussion = None
    active_messages = []

    if active_discussion_id:
        # Fetch the active discussion and messages from the database
        cursor.execute("SELECT * FROM discussions WHERE id = %s", (active_discussion_id,))
        active_discussion = cursor.fetchone()

        if active_discussion:
            cursor.execute("""
                SELECT m.contenu AS contenu, m.sender_id, u.pseudo AS sender_name
                FROM messages m
                JOIN users u ON m.sender_id = u.id
                WHERE m.discussion_id = %s
                ORDER BY m.date_envoi ASC
            """, (active_discussion_id,))
            active_messages = cursor.fetchall()
    
    # Fetch all discussions for the sidebar
    cursor.execute("""
        SELECT d.id, 
               u.pseudo AS recipient_name, 
               d.updated_at, 
               u.image AS recipient_image
        FROM discussions d
        JOIN users u ON d.recipient_id = u.id
        WHERE d.sender_id = %s OR d.recipient_id = %s
        ORDER BY d.updated_at DESC
    """, (current_user.id, current_user.id))
    discussions = cursor.fetchall()

    # Close the cursor and connection after all queries are executed
    cursor.close()
    conn.close()

    # Render the chat page with the required data
    return render_template(
        'chat.html',
        user_info=user_info,  # Pass user info for profile display
        discussions=discussions,  # Sidebar discussions
        active_discussion=active_discussion,  # Details of the active discussion
        active_messages=active_messages,  # Messages for the active discussion
        active_discussion_id=active_discussion_id  # ID of the active discussion
    )
                   
@login_required
@app.route('/create_discussion', methods=['GET', 'POST'], endpoint='create_discussion')
def create_discussion():
    if request.method == 'POST':
        recipient_id = request.form['recipient_id']

        # Check if recipient exists
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM users WHERE id = %s", (recipient_id,))
        recipient = cursor.fetchone()

        if not recipient:
            flash("Le destinataire n'existe pas.", "error")
            return redirect(url_for('create_discussion'))

        # Check if discussion already exists
        cursor.execute("""
            SELECT id FROM discussions 
            WHERE (sender_id = %s AND recipient_id = %s) 
               OR (sender_id = %s AND recipient_id = %s)
        """, (current_user.id, recipient_id, recipient_id, current_user.id))
        existing_discussion = cursor.fetchone()

        if existing_discussion:
            # Access the first element of the tuple (discussion ID)
            flash("La discussion existe déjà.", "info")
            return redirect(url_for('chat', discussion_id=existing_discussion[0]))

        # Create a new discussion
        query = """
            INSERT INTO discussions (sender_id, recipient_id) 
            VALUES (%s, %s)
        """
        try:
            cursor.execute(query, (current_user.id, recipient_id))
            conn.commit()
            flash('Discussion créée avec succès!', 'success')
            return redirect(url_for('chat', discussion_id=cursor.lastrowid))
        except Exception as e:
            flash('Une erreur est survenue lors de la création de la discussion.', 'error')
        finally:
            cursor.close()
            conn.close()

    # Fetch all users except the current user
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT id, CONCAT(prenom, ' ', nom) AS full_name FROM users WHERE id != %s", (current_user.id,))
    users = cursor.fetchall()
    cursor.close()
    conn.close()

    return render_template('create_discussion.html', users=users)


@app.route('/delete_message/<int:message_id>', methods=['DELETE'])
@login_required
def delete_message(message_id):
    """
    Logic: Delete a specific message.
    - Removes the message from the database.
    """
    message = Message.query.get(message_id)
    if message and (message.sender_id == current_user.id or message.receiver_id == current_user.id):
        db.session.delete(message)
        db.session.commit()
        return '', 204
    return 'Message non trouvé', 404

@app.route('/clear_chat', methods=['POST'])
@login_required
def clear_chat():
    """
    Logic: Clear all chat messages for the user.
    - Deletes all messages involving the user.
    """
    Message.query.filter(
        (Message.sender_id == current_user.id) | (Message.receiver_id == current_user.id)
    ).delete()
    db.session.commit()
    return '', 204

@app.route('/send_message/<int:discussion_id>', methods=['POST'])
@login_required
def send_message(discussion_id):
    message_text = request.form['message']

    # Validate discussion_id
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM discussions WHERE id = %s", (discussion_id,))
    discussion = cursor.fetchone()

    if not discussion:
        flash("La discussion n'existe pas.", "error")
        return redirect(url_for('chat'))

    # Insert the message
    query = """
        INSERT INTO messages (discussion_id, sender_id, contenu) 
        VALUES (%s, %s, %s)
    """
    try:
        cursor.execute(query, (discussion_id, current_user.id, message_text))
        conn.commit()
        flash('Message envoyé avec succès!', 'success')
    except Exception as e:
        flash('Une erreur est survenue lors de l\'envoi du message.', 'error')
    finally:
        cursor.close()
        conn.close()

    return redirect(url_for('chat', discussion_id=discussion_id))

# === Campus ===
@routes.route('/campus')
def campus():
    """
    Logic: Display campus information.
    - Fetches campus data from a JSON file and renders the `campus.html` template.
    """
    user_info = None
    if 'user_id' in session:
        user_id = session['user_id']
        user_info = get_user_info(user_id)
    
    # Si user_info est None, on initialise un dictionnaire vide ou avec des valeurs par défaut.
    if user_info is None:
        user_info = {'image': 'default_image.jpg'}  # Par exemple, ajouter une image par défaut
    
    with open("campus.json", "r") as f:
        campus_data = json.load(f)
    
    return render_template('campus.html', user_info=user_info, campuses=campus_data)


# === Test Route (Example) ===
@routes.route('/test', methods=['POST'])
def test_post():
    """
    Logic: Simple test route to verify POST requests.
    - Returns a success message in JSON format.
    """
    return jsonify({"message": "POST reçu avec succès"}), 200

# Register the Blueprint
app.register_blueprint(routes)

if __name__ == "__main__":
    app.run(debug=True)