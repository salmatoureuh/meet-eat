import json
import mysql.connector

def load_campuses_from_json():
    # Load the campus.json file
    with open("campus.json", "r", encoding="utf-8") as f:
        return json.load(f)

def populate_campus_table():
    # Database connection
    connection = mysql.connector.connect(
        host="localhost",
        user="root",
        password="AMU25",  # Replace with your actual password
        database="meet_eat"  # Replace with your actual database name
    )
    cursor = connection.cursor()

    # Load campuses from JSON
    campuses = load_campuses_from_json()

    # Insert data into campus table
    insert_query = """
    INSERT INTO campus (nom, adresse, ville, code_postal, horaires, paiement, lat, lng)
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
    """
    for campus in campuses:
        cursor.execute(insert_query, (
            campus['nom'],
            campus.get('adresse'),
            campus.get('ville'),
            campus.get('code_postal'),
            campus.get('horaires'),
            campus.get('paiement'),
            campus.get('lat'),
            campus.get('lng')
        ))

    # Commit changes and close connection
    connection.commit()
    cursor.close()
    connection.close()
    print("Campuses have been successfully inserted into the database.")

if __name__ == "__main__":
    populate_campus_table()