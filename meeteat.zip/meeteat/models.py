import os
import datetime
import mysql.connector
import re
import logging
from sqlalchemy import Column, Integer, String, ForeignKey
from mysql.connector import errorcode
from werkzeug.security import generate_password_hash
from werkzeug.utils import secure_filename
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import relationship
from sqlalchemy.sql import text
from sqlalchemy.exc import IntegrityError
from flask import session
from flask_login import UserMixin, LoginManager
from contextlib import contextmanager
from datetime import datetime
from config import ALLOWED_EXTENSIONS

SQLALCHEMY_DATABASE_URI = 'mysql+mysqlconnector://root:AMU25@localhost/meet_eat'
db = SQLAlchemy()

def init_app(app):
    db.init_app(app)

class Invitation(db.Model):
    __tablename__ = 'invitations'
    
    id = db.Column(db.Integer, primary_key=True)
    envoyeur_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    receveur_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    statut = db.Column(db.Enum('en attente', 'accepté', 'refusé', name='statut_enum'), default='en attente')

    envoyeur = db.relationship('User', foreign_keys=[envoyeur_id], back_populates='invitations_envoyees')
    receveur = db.relationship('User', foreign_keys=[receveur_id], back_populates='invitations_reçues')

    def __repr__(self):
        return f'<Invitation {self.id} from {self.envoyeur.username} to {self.receveur.username}>'


class User(db.Model, UserMixin):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(100), nullable=False)
    prenom = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    image = db.Column(db.String(120), nullable=True)
    num_etudiant = db.Column(db.String(15), unique=True, nullable=False)
    campus_id = db.Column(db.Integer, db.ForeignKey('campus.id'), nullable=False)
    campus = db.relationship('Campus', backref='users')
    ville = db.Column(db.String(100), nullable=False)
    adresse = db.Column(db.String(200), nullable=False)
    pseudo = db.Column(db.String(30), unique=True, nullable=False)
    date_inscription = db.Column(
        db.TIMESTAMP,
        default=db.func.current_timestamp(),
        onupdate=db.func.current_timestamp()
    )

    # Relationships
    reservations = db.relationship('Reservation', back_populates='user')
    invitations_envoyees = db.relationship(
        "Invitation",
        foreign_keys='Invitation.envoyeur_id',
        back_populates="envoyeur"
    )
    invitations_reçues = db.relationship(
        "Invitation",
        foreign_keys='Invitation.receveur_id',
        back_populates="receveur"
    )
    sent_messages = db.relationship(
        'Message',
        foreign_keys='Message.sender_id',
        back_populates='sender'
    )
    received_messages = db.relationship(
        'Message',
        foreign_keys='Message.receiver_id',
        back_populates='receiver'
    )

    def __repr__(self):
        return f'<User {self.nom} {self.prenom}>'

    def to_dict(self):
        """
        Convert the User object to a dictionary representation.
        """
        return {
            "id": self.id,
            "nom": self.nom,
            "prenom": self.prenom,
            "email": self.email,
            "pseudo": self.pseudo,
            "ville": self.ville,
            "adresse": self.adresse,
            "image": self.image,
        }

    def __init__(self, **kwargs):
        """
        Initialize the User object and handle nullable relationship fields.
        """
        # Relations to ignore in kwargs if they are None
        relations = ['invitations_envoyees', 'invitations_reçues']
        for relation in relations:
            if relation in kwargs and kwargs[relation] is None:
                kwargs.pop(relation)
        super().__init__(**kwargs)


# CampusTable model
class CampusTable(db.Model):
    __tablename__ = 'campus_tables'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    campus_id = db.Column(db.Integer, db.ForeignKey('campus.id', ondelete='CASCADE'), nullable=False)
    numero_table = db.Column(db.Integer, nullable=False)
    est_reserve = db.Column(db.Boolean, default=False)

    # Constraints
    __table_args__ = (
        db.UniqueConstraint('campus_id', 'numero_table', name='unique_campus_table'),
    )

    # Relationships
    campus = db.relationship('Campus', back_populates='tables')  # Matches the `tables` relationship in Campus
    reservations = db.relationship('Reservation', back_populates='campus_table', cascade="all, delete-orphan")  # Matches the `campus_table` relationship in Reservation

    def __repr__(self):
        return f"<CampusTable campus_id={self.campus_id} numero_table={self.numero_table}>"

# Reservation model
class Reservation(db.Model):
    __tablename__ = 'reservation'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    table_id = db.Column(db.Integer, db.ForeignKey('campus_tables.id', ondelete='CASCADE'), nullable=False)
    date_reservation = db.Column(db.DateTime, nullable=False)
    heure_debut = db.Column(db.Time, nullable=False)
    heure_fin = db.Column(db.Time, nullable=False)
    campus_nom = db.Column(db.String(255), nullable=False)

    # Relationships
    campus_table = db.relationship('CampusTable', back_populates='reservations')  # Matches the `reservations` relationship in CampusTable
    user = db.relationship('User', back_populates='reservations')  # Matches the `reservations` relationship in User

    def __repr__(self):
        return f"<Reservation user_id={self.user_id} table_id={self.table_id} date_reservation={self.date_reservation}>"

class Message(db.Model):
    __tablename__ = 'messages'
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    contenu = db.Column(db.Text, nullable=False)
    date_envoi = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    sender = db.relationship('User', foreign_keys=[sender_id], back_populates='sent_messages')
    receiver = db.relationship('User', foreign_keys=[receiver_id], back_populates='received_messages')

# Campus model
class Campus(db.Model):
    __tablename__ = 'campus'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nom = db.Column(db.String(255), nullable=False)
    adresse = db.Column(db.String(255))
    ville = db.Column(db.String(100))
    code_postal = db.Column(db.String(20))
    horaires = db.Column(db.String(255))
    paiement = db.Column(db.String(100))
    lat = db.Column(db.Float)
    lng = db.Column(db.Float)

    # Relationships
    tables = db.relationship('CampusTable', back_populates='campus', cascade="all, delete-orphan")  # Matches the `campus` relationship in CampusTable

    def __repr__(self):
        return f"<Campus {self.nom}>"

# Database connection management
def get_db_connection():
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="AMU25",
            database="meet_eat"
        )
        return conn
    except mysql.connector.Error as err:
        print("Erreur de connexion à la base de données :", err)
        return None


@contextmanager
def get_db_cursor():
    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)
    try:
        yield connection, cursor
    finally:
        cursor.close()
        connection.close()

def allowed_file(filename):
    return (
        "." in filename
        and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS
    )




def create_user(prenom, nom, pseudo, email, password_hash, num_etudiant, campus_id, ville, adresse, image):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO users (prenom, nom, pseudo, email, password_hash, num_etudiant, campus_id, ville, adresse, image)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (prenom, nom, pseudo, email, password_hash, num_etudiant, campus_id, ville, adresse, image))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print("Erreur dans create_user():", e)
        return False

def get_campuses_from_db():
    # Database connection
    connection = mysql.connector.connect(
        host="localhost",
        user="root",
        password="AMU25",  # Replace with your actual password
        database="meet_eat"  # Replace with your actual database name
    )
    cursor = connection.cursor(dictionary=True)

    # Query to fetch all campuses
    query = "SELECT id, nom FROM campus"
    cursor.execute(query)
    campuses = cursor.fetchall()

    cursor.close()
    connection.close()
    return campuses

def get_campus_id_by_name(campus_name):
    sql = text("SELECT id FROM campus WHERE nom = :campus_name")
    result = db.session.execute(sql, {'campus_name': campus_name}).fetchone()
    return result[0] if result else None

def is_valid_password(password):
    password_regex = r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{6,}$'
    return re.match(password_regex, password)

def get_user_by_email(email):
    return User.query.filter_by(email=email).first()

def get_user_by_num_etudiant(num_etudiant):
    return User.query.filter_by(num_etudiant=num_etudiant).first()

def get_user_info(user_id):
    try:
        user = db.session.query(User).filter(User.id == user_id).first()
        if user:
            return {
                'id': user.id,
                'nom': user.nom,
                'prenom': user.prenom,
                'num_etudiant': user.num_etudiant,
                'campus_id': user.campus_id,
                'ville': user.ville,
                'adresse': user.adresse,
                'date_inscription': user.date_inscription,
                'email': user.email,
                'image': user.image,
                'pseudo': user.pseudo
            }
        return None
    except Exception as e:
        print(f"Erreur lors de la récupération de l'utilisateur : {e}")
        return None

def update_user_info(user_id, data, image_filename=None):
    conn = get_db_connection()
    cursor = conn.cursor()
    if image_filename:
        update_query = """
            UPDATE users 
            SET prenom = %s, nom = %s, email = %s, campus_id = %s, ville = %s, adresse = %s, image = %s, pseudo = %s
            WHERE id = %s
        """
        params = (
            data['prenom'], data['nom'], data['email'],
            data['campus_id'], data['ville'], data['adresse'], image_filename, data ['pseudo'], user_id
        )
    else:
        update_query = """
            UPDATE users 
            SET prenom = %s, nom = %s, email = %s, campus_id = %s, ville = %s, adresse = %s, pseudo = %s
            WHERE id = %s
        """
        params = (
            data['prenom'], data['nom'], data['email'],
            data['campus_id'], data['ville'], data['adresse'], data ['pseudo'], user_id
        )
    try:
        cursor.execute(update_query, params)
        conn.commit()
        return True
    except mysql.connector.Error as err:
        print(f"❌ Erreur lors de la mise à jour des informations : {err}")
        conn.rollback()
        return False
    finally:
        cursor.close()
        conn.close()

def delete_user_by_id(user_id):
    connection = get_db_connection()
    cursor = connection.cursor()
    query = "DELETE FROM users WHERE id = %s"
    try:
        cursor.execute(query, (user_id,))
        connection.commit()
        return cursor.rowcount > 0
    except mysql.connector.Error as err:
        print(f"❌ Erreur lors de la suppression de l'utilisateur : {err}")
        return False
    finally:
        cursor.close()
        connection.close()
def create_private_meal(organisateur_id, date_repas, heure, campus_id):
    """
    Logic: Create a private meal in the database.
    - This inserts a new private meal for the given organizer, date, time, and campus.
    """
    connection = get_db_connection()
    cursor = connection.cursor()

    query = """
    INSERT INTO private_meals (organisateur_id, date_repas, heure, campus_id)
    VALUES (%s, %s, %s, %s)
    """
    
    try:
        cursor.execute(query, (organisateur_id, date_repas, heure, campus_id))
        connection.commit()
        print("Repas privé créé avec succès.")
        return cursor.lastrowid  # Returns the ID of the newly created meal
    except mysql.connector.Error as err:
        print(f"❌ Erreur lors de la création du repas privé : {err}")
        return None
    finally:
        cursor.close()
        connection.close()

from datetime import datetime

def create_reservation(user_id, table_id, nb_personnes, date_reservation, heure_debut, heure_fin, campus_nom):
    """
    Crée une réservation pour un utilisateur, une table, et un nombre de personnes donnés.
    """

    try:
        # Conversion de la date de réservation en un objet datetime
        date_reservation = datetime.strptime(date_reservation, "%Y-%m-%d %H:%M")

        # Création de la nouvelle réservation
        new_reservation = Reservation(
            user_id=user_id,
            date_reservation=date_reservation,
            heure_debut=heure_debut,
            heure_fin=heure_fin,
            campus_nom=campus_nom,
            table_id=table_id
        )

        # Ajout à la session et commit
        db.session.add(new_reservation)
        db.session.commit()

        return True, "✅ Réservation créée avec succès."

    except Exception as e:
        db.session.rollback()  # Annuler les changements en cas d'erreur
        return False, f"❌ Une erreur est survenue lors de la création de la réservation : {str(e)}"

@staticmethod
def check_table_availability(table_id, date_reservation, heure_debut, heure_fin):
    reservations = Reservation.query.filter(
        Reservation.table_id == table_id,
        Reservation.date_reservation == date_reservation,
        Reservation.heure_debut < heure_fin,
        Reservation.heure_fin > heure_debut
    ).all()
    return len(reservations) == 0  # Retourne True si aucune réservation ne chevauche

def get_reservations_from_db(user_id):
    """
    Fetch reservations for a given user from the database.
    """
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)

        query = """
            SELECT r.id, r.date_reservation, r.heure_debut, r.heure_fin, c.nom AS campus_nom
            FROM reservation r
            JOIN campus_tables t ON r.table_id = t.id
            JOIN campus c ON t.campus_id = c.id
            WHERE r.user_id = %s
            ORDER BY r.date_reservation DESC
        """
        cursor.execute(query, (user_id,))
        reservations = cursor.fetchall()

        if not reservations:
            return []  # Renvoie une liste vide si aucune réservation n'est trouvée

        # Formatage des données pour un usage plus facile
        formatted_reservations = []
        for res in reservations:
            formatted_reservations.append({
                'id': res['id'],
                'date_reservation': res['date_reservation'].strftime('%Y-%m-%d'),
                'heure_debut': res['heure_debut'].strftime('%H:%M'),
                'heure_fin': res['heure_fin'].strftime('%H:%M'),
                'campus_id': res['campus_id'],
                'table_nom': res['table_nom'],
                'campus_nom': res['campus_nom']
            })

        return formatted_reservations
    
    except Exception as e:
        logging.error(f"Error fetching reservations for user {user_id}: {e}")
        return None
    
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()




def delete_reservation_from_db(reservation_id):
    """
    Logic: Delete a reservation from the database.
    - Removes the reservation entry by its ID.
    """
    connection = None
    cursor = None

    try:
        connection = get_db_connection()
        cursor = connection.cursor()

        query = "DELETE FROM reservation WHERE id = %s"
        cursor.execute(query, (reservation_id,))
        connection.commit()

        if cursor.rowcount > 0:
            return True, f"✅ Reservation ID {reservation_id} deleted successfully."
        else:
            return False, f"❌ No reservation found with ID {reservation_id}."
    except Exception as e:
        if connection:
            connection.rollback()
        return False, f"❌ Error deleting reservation: {e}"
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()


def add_reservation_notification(user_id, date, heure, campus_nom, table_id):
    """
    Logic: Add a notification for a reservation.
    - Notifies the user about their reservation details.
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    query = """
    INSERT INTO notifications (user_id, message, type, date_notification)
    VALUES (%s, %s, 'reservation', NOW())
    """
    message = f"✅ Votre réservation pour la Table {table_id} à {campus_nom} le {date} à {heure} a été confirmée."
    try:
        cursor.execute(query, (user_id, message))
        conn.commit()
        print("✅ Notification de réservation ajoutée avec succès.")
        return True
    except Exception as e:
        conn.rollback()
        print(f"❌ Erreur lors de l'ajout de la notification de réservation : {e}")
        return False
    finally:
        cursor.close()
        conn.close()

def get_unread_notifications(user_id):
    """
    Logic: Fetch unread notifications for a user.
    - Retrieves all notifications marked as unread.
    """
    query = """
    SELECT * FROM notifications
    WHERE user_id = %s AND est_lu = FALSE;
    """
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    try:
        cursor.execute(query, (user_id,))
        notifications = cursor.fetchall()
        return notifications
    except Exception as e:
        print(f"❌ Error fetching notifications: {e}")
        return []
    finally:
        cursor.close()
        conn.close()

def mark_notification_as_read(notification_id):
    """
    Logic: Mark a notification as read.
    - Updates the notification's status to 'read' in the database.
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    query = """
    UPDATE notifications
    SET est_lu = TRUE
    WHERE id = %s
    """
    try:
        cursor.execute(query, (notification_id,))
        conn.commit()
        print("✅ Notification marked as read.")
        return True
    except Exception as e:
        conn.rollback()
        print(f"❌ Error marking notification as read: {e}")
        return False
    finally:
        cursor.close()
        conn.close()

def search_friends(query):
    """
    Logic: Search for friends by their pseudo or name.
    - Returns a list of matching users.
    """
    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)

    search_query = """
    SELECT id, nom, prenom, pseudo, image
    FROM users
    WHERE pseudo LIKE %s OR nom LIKE %s OR prenom LIKE %s
    """
    
    try:
        cursor.execute(search_query, (f'%{query}%', f'%{query}%', f'%{query}%'))
        results = cursor.fetchall()
        return results
    except mysql.connector.Error as err:
        print(f"❌ Erreur lors de la recherche d'amis : {err}")
        return []
    finally:
        cursor.close()
        connection.close()


def send_notification(user_id, message):
    """
    Logic: Send a notification to a user.
    - Inserts a notification into the database with a default unread status.
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    query = """
        INSERT INTO notifications (user_id, message, est_lu, type)
        VALUES (%s, %s, FALSE, 'invitation')
    """
    try:
        cursor.execute(query, (user_id, message))
        conn.commit()
        print("✅ Notification sent to user.")
        return True
    except Exception as e:
        conn.rollback()
        print(f"❌ Error sending notification: {e}")
        return False
    finally:
        cursor.close()
        conn.close()

def add_friend(user_id, friend_id):
    """
    Logic: Add a new friend request.
    - Inserts a friend request into the database with a pending status.
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            INSERT INTO friends (user_id, friend_id, statut)
            VALUES (%s, %s, 'en attente')
        """, (user_id, friend_id))
        conn.commit()
        print("✅ Friend request added successfully.")
        return True
    except mysql.connector.Error as err:
        conn.rollback()
        print(f"❌ Error adding friend: {err}")
        return False
    finally:
        cursor.close()
        conn.close()

def send_invitation(envoyeur_id, receveur_id, repas_id):
    """
    Logic: Send an invitation for a private meal.
    - Adds an entry in the invitations table.
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            INSERT INTO invitations (envoyeur_id, receveur_id, repas_id, statut)
            VALUES (%s, %s, %s, 'en attente')
        """, (envoyeur_id, receveur_id, repas_id))
        conn.commit()
        print("✅ Invitation sent successfully.")
        return True
    except mysql.connector.Error as err:
        conn.rollback()
        print(f"❌ Error sending invitation: {err}")
        return False
    finally:
        cursor.close()
        conn.close()

def create_notification(user_id, message):
    """
    Logic: Add a notification to the database.
    - Associates the notification with a specific user.
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    query = """
        INSERT INTO notifications (user_id, message)
        VALUES (%s, %s)
    """
    try:
        cursor.execute(query, (user_id, message))
        conn.commit()
        print("✅ Notification created successfully.")
        return True
    except Exception as e:
        conn.rollback()
        print(f"❌ Error creating notification: {e}")
        return False
    finally:
        cursor.close()
        conn.close()

def send_message(sender_id, receiver_id, contenu):
    """
    Logic: Send a message between users.
    - Adds the message entry to the database.
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            INSERT INTO messages (sender_id, receiver_id, contenu)
            VALUES (%s, %s, %s)
        """, (sender_id, receiver_id, contenu))
        conn.commit()
        print("✅ Message sent successfully.")
        return True
    except mysql.connector.Error as err:
        conn.rollback()
        
        # Check for specific foreign key constraint violations
        if "FOREIGN KEY" in str(err):
            if "sender_id" in str(err):
                print(f"❌ Sender ID {sender_id} does not exist.")
            elif "receiver_id" in str(err):
                print(f"❌ Receiver ID {receiver_id} does not exist.")
            else:
                print(f"❌ Foreign key constraint error: {err}")
        else:
            print(f"❌ Error sending message: {err}")
        
        return False
    finally:
        cursor.close()
        conn.close()

def get_user_by_field(field, value):
    """
    Logic: Fetch a user by a specific field and value.
    - Supports searching by email or student ID.
    """
    valid_fields = ['email', 'num_etudiant']
    if field not in valid_fields:
        raise ValueError(f"Invalid field '{field}'.")

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    query = f"SELECT * FROM users WHERE {field} = %s"
    try:
        cursor.execute(query, (value,))
        user = cursor.fetchone()
        return user
    except Exception as e:
        print(f"❌ Error fetching user by {field}: {e}")
        return None
    finally:
        cursor.close()
        conn.close()

def add_friend_request_notification(user_id, friend_id):
    """
    Logic: Add a notification for a friend request.
    - Notifies the receiving user about the friend request.
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    query = """
    INSERT INTO notifications (user_id, message, type, sender_id, est_lu)
    VALUES (%s, %s, 'friend_request', %s, FALSE)
    """
    message = f"🔔 Vous avez une nouvelle demande d'ami !"
    try:
        cursor.execute(query, (friend_id, message, user_id))
        conn.commit()
        print("✅ Friend request notification added successfully.")
        return True
    except Exception as e:
        conn.rollback()
        print(f"❌ Error adding friend request notification: {e}")
        return False
    finally:
        cursor.close()
        conn.close()



def get_campus_info():
    """
    Logic: Fetch all campus information from the database.
    - Retrieves and returns all campus entries.
    """
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    query = "SELECT * FROM campus"
    try:
        cursor.execute(query)
        campuses = cursor.fetchall()
        print("✅ Campus information retrieved successfully.")
        return campuses
    except mysql.connector.Error as err:
        print(f"❌ Error retrieving campus information: {err}")
        return []
    finally:
        cursor.close()
        conn.close()


