# config.py
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif"}
